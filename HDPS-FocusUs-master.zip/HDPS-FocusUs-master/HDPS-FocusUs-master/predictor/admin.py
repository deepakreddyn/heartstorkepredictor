from django.contrib import admin
from .models import HeartData,DoctorHospital
# Register your models here.
admin.site.register(HeartData)
admin.site.register(DoctorHospital)