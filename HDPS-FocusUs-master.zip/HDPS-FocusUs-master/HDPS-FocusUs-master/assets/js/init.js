$ (function(){
  $(function(){

    $('.sidenav').sidenav();

    $('.slider').slider({
      fullWidth: true,
      indicators: false,
      height: 600
      
    });

    $('.sliderb').slider({
      fullWidth: true,
      indicators: false,
      height: 284
      
    });

    $('.sliderv').slider({
      fullWidth: true,
      indicators: false,
      height: 284
      
    });

  }); // end of document ready
})(jQuery); // end of jQuery name space
